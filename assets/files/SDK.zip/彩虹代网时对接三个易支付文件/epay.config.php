<?php
/* *
、 * 此文件可以将代刷网qq钱包、支付宝、微信，三种支付方式分别对接三个不同的易支付
 * 配置好该文件，将此文件上传到代刷网网站根目录/other/epay,将里面的epay文件夹里面epay.config.php文件替换成此文件即可！
 * 上传此文件之后，代刷网网站后台的接口配置那里就不用改动了，随便怎么设置都不用管！
注意：替换该文件之后，后台首页会显示错误，记得将/admin/index.php里面的$sec_msg = sec_check();这一行删掉，搜索下这句代码，删掉这行代码就不会提示错误了！
注意：替换该文件之后，后台首页会显示错误，记得将/admin/index.php里面的$sec_msg = sec_check();这一行删掉，搜索下这句代码，删掉这行代码就不会提示错误了！
注意：替换该文件之后，后台首页会显示错误，记得将/admin/index.php里面的$sec_msg = sec_check();这一行删掉，搜索下这句代码，删掉这行代码就不会提示错误了！
 */
//↓↓↓↓↓↓↓↓↓↓请在这里配置您的基本信息↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓
//下面是支付宝接口
//下面是支付宝接口
//下面是支付宝接口
//商户ID
$alipay_config['partner']		= '商户id';//此处输入对接支付宝易支付的商户id
//商户KEY
$alipay_config['key']			= '商户密钥key';//此处输入对接支付宝易支付的商户密钥key
//签名方式 不需修改
$alipay_config['sign_type']    = strtoupper('MD5');
//字符编码格式 目前支持 gbk 或 utf-8
$alipay_config['input_charset']= strtolower('utf-8');
//访问模式,根据自己的服务器是否支持ssl访问，若支持请选择https；若不支持请选择http
$alipay_config['transport']    = 'http';
//支付宝支付API地址
$alipay_config['apiurl']    = 'http:///';//此处填写某某易支付的支付API
//--------------------------------------分割线----------------------------------------------------//
//下面是微信接口
//下面是微信接口
//下面是微信接口
if($type=='wxpay' || $_GET['type']=='wxpay'){
//商户ID
$alipay_config['partner']		= '商户id';//此处输入对接微信易支付的商户id（举例：如果微信对接某某易支付，此处请填写在某某易支付注册的ID和密钥）
//商户KEY
$alipay_config['key']			= '商户密钥key';//此处输入对接微信易支付的商户密钥key
//微信支付API地址
$alipay_config['apiurl']    = 'http:///';//此处填写某某易支付的支付API
}
//--------------------------------------分割线----------------------------------------------------//
//下面是QQ钱包接口
//下面是QQ钱包接口
//下面是QQ钱包接口
if($type=='qqpay' || $_GET['type']=='qqpay'){
//商户ID
$alipay_config['partner']		= '商户id';//此处输入对接QQ钱包易支付的商户id
//商户KEY
$alipay_config['key']			= '商户密钥key';//此处输入对接QQ钱包易支付的商户密钥key
//QQ钱包支付API地址
$alipay_config['apiurl']    = 'http:///';//此处填写某某易支付的支付API
}

?>